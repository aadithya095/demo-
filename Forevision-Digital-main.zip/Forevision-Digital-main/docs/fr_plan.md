# Functional Requirement Plan
## User Login and Sign-Up
## User Dashboard
### Profile
### Upload

## Admin Login 
## Admin Dashboard
###[^1]


[^1]: 
